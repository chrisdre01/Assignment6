import { lazy } from 'react';
import React from 'react';

const MarkdownPreview = lazy(() => import('./MarkdownPreview.js'));

function Page2() {
    return (
        <>
            <h3>Page 2</h3>
        </>
    )
}
export default Page2;
