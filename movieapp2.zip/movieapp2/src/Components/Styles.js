import React from "react";
import { Text, View } from "react-native";
import styles from "./Styles";

export default function App() {
    return (
        <View style={styles.container}>
            <View style={styles.box}>
                <Text style={styles.boxText}>Home</Text>
            </View>
            <View style={styles.box}>
                <Text style={styles.boxText}>Movies</Text>
            </View>
            <View style={styles.box}>
                <Text style={styles.boxText}>Page 2</Text>
            </View>
            <View style={styles.box}>
            <Text style={styles.boxText}>About</Text>
        </View>
    </View>
    );
}

