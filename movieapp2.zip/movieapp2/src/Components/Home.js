import React from "react";
import { View, Text, Button, StatusBar } from "react-native";
import styles from "./Styles";

export default function Home({ navigation }) {
    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" />
            <Text>Home Screen</Text>
            <Button
                title="SoberGraphx Movies"
                onPress={() => navigation.navigate("Movies",
                    { title: "Movies" })}
            />
            <Button
            title="Page 2"
            onPress={() => navigation.navigate("Page 2",
                { title: "Page 2" })}
            />
            <Button
            title="About"
            onPress={() => navigation.navigate("About",
                { title: "About" })}
            />
        </View>
    );
}