import React from 'react';

function Blog() {
    return (
        <>
            <h3>Blog</h3>
        </>
    )
}
export default Blog;