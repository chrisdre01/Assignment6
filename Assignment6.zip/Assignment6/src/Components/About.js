import React from 'react';

function About() {
    return (
        <>
            <h3>About</h3>
        </>
    )
}
export default About;